Steps to setup the Fbook tool

get the following files
 Fbook.zip
 flask_httpServer_8080.py
 flask_httpServer_5000.py

make sure you have the following packages installed in your local python 
if not:
pip3 install openai
pip3 install flask_cors

Then run the following
   python3 flask_httpServer_8080.py   | to enable the http server with GET method
   python3 flask_httpServer_5000.py   | to enable the POST method

go to the directory where you run flask_httpServer and create the uploads directory
mkdir uploads
make it writable
chmod a+w uploads

define the environment variable OPENAI_API_KEY
bash
export OPENAI_API_KEY='sk-proj-QAElYlbIMQ20RDzldlNmT3BlbkFJiQA22SZWi0qRwbfMv5EV'
csh
setenv OPENAI_API_KEY 'sk-proj-QAElYlbIMQ20RDzldlNmT3BlbkFJiQA22SZWi0qRwbfMv5EV'


To get the audio running do the following

install node.js

mkdir openai-audio-proxy
cd openai-audio-proxy
npm init -y
npm install express multer axios dotenv

copy index.js from /Users/paologiommi/openai-audio-proxy

CORS
npm install cors

Run node
node index.js



